import React, { Component } from 'react';
import { Navigation ,TabNavigator,TabBarBottom,StackNavigator,SwitchNavigator } from 'react-navigation';
import Icon from 'react-native-vector-icons/MaterialIcons';
import HomeScreen  from './HomeScreen';
import SettingsScreen  from './SettingsScreen';
import NotificationScreen  from './NotificationScreen';
import Profile  from './Profile';
import Dashboard  from './Dashboard';
import Login  from './Login';
import Forgot_password  from './Forgot_password';
import InstitutionList from './InstitutionList';
import FeeComponent from './Fee';
import FeedbackComponent from './Feedback';
import FinanceComponent from './Finance';
import AdmissionComponent from './Admission';

export const SignedOut = StackNavigator({
  Login: {
    screen: Login,
    navigationOptions: {
      title: "Login ",
      
    }
  },
  Forgot_password: {
    screen: Forgot_password,
    navigationOptions: {
      title: "Forgot_password",
      
    }
  }
});

export const DashboardTabs = StackNavigator({
  Dashboard: { screen: Dashboard },
  Institutions : { screen : InstitutionList },
  fee : { screen : FeeComponent },
  feedback : { screen : FeedbackComponent },
  finance : { screen : FinanceComponent },
  account : { screen : AdmissionComponent }
});

export const SignedIn = TabNavigator({
  Home: { screen: HomeScreen },
  Setting: { screen: SettingsScreen },
  DashboardTab: DashboardTabs,
  Profile: { screen: Profile },
  Notification: { screen: NotificationScreen },

},
  {
    navigationOptions: ({ navigation }) => ({
      tabBarIcon: ({ focused, tintColor }) => {
        const { routeName } = navigation.state;
        let iconName;
        if (routeName === 'Home') {
          iconName = "home";
        } else if (routeName === 'Setting') {
          iconName = "settings";
        }else if (routeName === 'Profile') {
          iconName = "person";
        }else if (routeName === 'Notification') {
          iconName = "notifications";
        }else if (routeName === 'DashboardTab') {
          iconName = "dashboard";
        }

        // You can return any component that you like here! We usually use an
        // icon component from react-native-vector-icons
        return <Icon size={24} color={tintColor} name={iconName} />;
      },
    }),
    tabBarOptions: {
      activeTintColor: 'tomato',
      inactiveTintColor: 'gray',
    },
    tabBarComponent: TabBarBottom,
    tabBarPosition: 'bottom',
    animationEnabled: false,
    swipeEnabled: true,
  }
);


export const createRootNavigator = (signedIn = false) => {
  return SwitchNavigator(
    {
      SignedIn: {
        screen: SignedIn
      },
      SignedOut: {
        screen: SignedOut
      }
    },
    {
      initialRouteName: signedIn ? "SignedIn" : "SignedOut"
    }
  );
};