import React, { Component } from 'react';
import {
	 StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
  ListView,
  TabBarIOS,
  ScrollView,
  FlatList,
Alert,
} from 'react-native';
//import Login from './app/src/Login';

import BottomNavigation, { Tab } from 'react-native-material-bottom-navigation';
import Icon from 'react-native-vector-icons/MaterialIcons';
//	import Icon from ‘react-native-vector-icons/FontAwesome’

export default class Dashboard extends Component {



static navigationOptions = {
    title: 'DashBoard',
  };
  constructor() {
    super();

    this.state = { FlatListItems: [
      {key: 'One'},
      {key: 'Two'},
      {key: 'Three'},
      {key: 'Four'},
      {key: 'Five'},
      {key: 'Six'},
      {key: 'Seven'},
      {key: 'Eight'},
      {key: 'Nine'},
      {key: 'Ten'},
      {key: 'Eleven'},
      {key: 'Twelve'}
    ]}
  }

FlatListItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%",
          backgroundColor: "#607D8B",
        }}
      />
    );
  }
 GetItem (item) {
   
  Alert.alert(item);
 
  }
renderItem = ({item}) => {
return <Text style={styles.item} onPress={this.GetItem.bind(this, item.key)} > {item.key} </Text>
}
  render() {

    return (
    	  
    	
        
        <View  style={styles.container}>
        	
		<FlatList
           data={ this.state.FlatListItems }
          ItemSeparatorComponent={this.FlatListItemSeparator}
         
          renderItem={this.renderItem}
        />
		    
        </View>
    
       
        

    );
  }

 
}
const styles = StyleSheet.create({

container: {
    flex: 1,
    margin: 10,
    backgroundColor: '#fff',
    justifyContent:'center',

   

   
},

item: {
    padding: 10,
    fontSize: 18,
    height: 44,
  },

});
