import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
  Button,
  Form,
PixelRatio,
  TabBarIOS,
  ScrollView,
} from 'react-native';
import ImagePicker from 'react-native-image-picker';


export default class Profile extends Component {

    state = {
 
      ImageSource: null,
    
    };
 static navigationOptions = ({navigation})=>({
    title: 'Profile',
    headerRight:<TouchableOpacity onPress={()=> navigation.navigate("Login")}>
      <Text style={{marginRight:10,color:'green'}}>Save</Text>
    </TouchableOpacity>
  });
selectPhotoTapped() {
      const options = {
        quality: 1.0,
        maxWidth: 500,
        maxHeight: 500,
        storageOptions: {
          skipBackup: true
        }
      };
  
      ImagePicker.showImagePicker(options, (response) => {
        console.log('Response = ', response);
  
        if (response.didCancel) {
          console.log('User cancelled photo picker');
        }
        else if (response.error) {
          console.log('ImagePicker Error: ', response.error);
        }
        else if (response.customButton) {
          console.log('User tapped custom button: ', response.customButton);
        }
        else {
          let source = { uri: response.uri };
  
          // You can also display the image using data:
          // let source = { uri: 'data:image/jpeg;base64,' + response.data };
  
          this.setState({
 
            ImageSource: source
 
          });
        }
      });
    }

  render() {

    return (
    

        <View  style={styles.container}>
        <ScrollView>
          <View style={{paddingRight:30,paddingLeft:30,marginTop:30}}>
          
         
            <TouchableOpacity style = {styles.profilepicWrap}
            onPress={this.selectPhotoTapped.bind(this)} >
              { this.state.ImageSource === null ?
		<Image
                style = {styles.profilepic}
                  source={require('../images/logo.png')}>
                  </Image> :
                <Image style={styles.profilepic} source={this.state.ImageSource} />
             }
             
            </TouchableOpacity>
            
            <Text style={styles.anchorTag}>Change Photo</Text>

     
          <Text> Name </Text>
          <TextInput
            autoCapitalize = "none"
            underlineColorAndroid = "transparent"
            style = {styles.textInput}
           >
          </TextInput>

       
          <Text> Enroll Number </Text>
          <TextInput
            placeholderTextColor = '#cccccc'
            autoCapitalize = "none"
            underlineColorAndroid = "transparent"
            style = {styles.textInput}
           >
          </TextInput>

       
          <Text>Email Address</Text>
          <TextInput
            autoCapitalize = "none"
            underlineColorAndroid = "transparent"
            style = {styles.textInput}
           >
          </TextInput>

       
          <Text>Phone Number</Text>
          <TextInput
            autoCapitalize = "none"
            underlineColorAndroid = "transparent"
            style = {styles.textInput}
           >
          </TextInput>
         	<View style={{marginTop:20,}}>
		</View>
          </View>
      </ScrollView>
      
        </View>       
    
       

  
    );
   
    }
}
const styles = StyleSheet.create({
logo:{
  flex:1,
  resizeMode:'cover',
  position:'absolute',
  width:'100%',
  height:'100%',
  justifyContent:'center',
},
logotitle:{
	alignSelf:'center',
	marginBottom:30,
	fontWeight: "bold",
},
container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent:'center',
    alignSelf: 'center',
    width:'100%',
//    alignItems:'center'
   
},
profileContainer:{		
	marginLeft:20,
	marginRight:20,
	marginTop:10,
},
header:{
	flex:1,
	alignItems:'center',
	justifyContent:'center',
	//padding:20,
	//backgroundColor:'rgba(0,0,0,0.5)',
},
profilepicWrap:{
	marginTop:5,
	//marginBottom:25,
	width:150,
	height:150,
	
	borderColor:'rgba(0,0,0,0.4)',
	alignSelf:'center',

},
profilepic:{

		flex:1,
		width:null,
                resizeMode: 'contain',
		
		borderColor:'#000',
		borderWidth:1,
},
profilepicchange:{
	marginTop:15,
	marginBottom:35,
	fontSize:16,
	color:'#000',
	fontWeight:'bold',
	alignSelf:'center',
},
logincontainer:{
	//borderRadius: 4,
    //borderWidth: 0.5,
   // borderColor: '#d6d7da',
    //backgroundColor:'#fff',
    marginLeft : 20,
    marginRight:20,
    width:352,
    alignItems:'center',
    height:500,
  //  padding:20,
    justifyContent:'center',
},
h3bigger:{
	fontSize:16,
	marginRight:'85%',
},
h4:{
	fontSize:12,
	marginRight:'65%',
},
loginTextInput:{
	alignSelf: 'stretch',
	padding:2,
	marginBottom: 20,
	backgroundColor: '#fff',
	borderRadius: 4,
    borderWidth: 0.5,
    borderColor: '#d6d7da',
},
loginbutton:{
	
	alignSelf: 'stretch',
	alignItems: 'center',
	backgroundColor:'#3399ff',
	padding:10,
	marginTop:10,
},
loginButton:{
	color:'#fff',
      textAlign:'center',
      paddingLeft : 10,
      paddingRight : 10
},
anchorTag:{
	fontSize:12,
	color:'#000',
	padding:10,
	marginTop:10,
	alignSelf:'center',
},
space:{
	paddingBottom:30,
},
rowView:{
	flexDirection:'row',
	alignSelf:'flex-start',
	justifyContent:'center',
	alignSelf:'center',
},
rowViewText:{
	flex:1,
	flexGrow:1,
	fontSize:12,
	marginTop:8,
},
footer:{
	height:40,
	position:'absolute',
	left:0,
	right:0,
	bottom:0,
	//borderColor:'black',
	//borderRadius: 4,
    //borderWidth: 0.5,
    //justifyContent:'center'
    alignItems:'center',
    alignSelf:'center',

},
DashboardSection:{
	borderRadius: 2,
    borderWidth: 0.3,
    borderColor: '#d6d7da',
    height:'100%',
    marginTop:10,
    backgroundColor: '#fff',
    alignSelf:'center',
    alignItems:'center',
    justifyContent:'center',
    width:'100%',
    
},
Dashbordfooter:{
 height: 56,
          elevation: 8,
          position: 'absolute',
          left: 0,
          bottom: 0,
          right: 0,
   borderTopColor: '#d6d7da',
    borderTopWidth: StyleSheet.hairlineWidth,
},
textInput:{
	//alignSelf: 'stretch',
	padding:2,
	marginTop:5,
	marginBottom: 15,
	//backgroundColor: '#fff',
	//borderRadius: 4,
    //borderWidth: 0.5,
    //borderColor: '#d6d7da',
    borderBottomWidth: 0.5,
    borderBottomColor: '#d6d7da',

}

});
