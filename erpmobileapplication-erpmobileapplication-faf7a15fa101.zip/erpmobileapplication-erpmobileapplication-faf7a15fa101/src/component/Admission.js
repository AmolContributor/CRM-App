import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    StatusBar,
    Image,
    Linking,
    CheckBox,
    Switch,
    ListView,
    TabBarIOS,
    ScrollView,
    FlatList,
    Alert,
    Button
  } from "react-native";

export default class AdmissionComponent extends Component {
    static navigationOptions = {
        title: "Admissions"
      };
    
      constructor() {
        super();
        this.state = {
          admissionData: []
        };
      }
    
      componentWillMount() {
        this.getAdmissionData(this.props.navigation.state.params);
      }
      
      getAdmissionData(param) {
        return fetch(
          "http://erpwebservice.nikole.in/listdata.php?productid="+param.data.productid
        )
          .then(response => response.json())
          .then(responseJson => {
            this.setState({
              isLoading: true,
              admissionData: responseJson.admissionintake
            });
          })
          .catch(error => {
            console.error(error);
          });
      }
    
      FlatListItemSeparator = () => {
        return (
          <View
            style={{
              height: 1,
              width: "100%"
            }}
          />
        );
      };
    
      renderItem = ({ item }) => {
        return (
            <View style={styles.submenuItem}>
                <Text style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}>
                   Total Admission Intake
                </Text>
                <View  style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'row' }}>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} > 
                    <Text style={{ marginTop: 10, fontSize: 14, textAlign: "center" }}>
                        Male
                    </Text>
                    <Text style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}>
                        {item.malecount}
                    </Text>
                    </View>
                
                    <View style={{ flex: 1, alignSelf: 'stretch' }} >
                    <Text style={{ marginTop: 10, fontSize: 14, textAlign: "center" }}>
                        Female
                    </Text>
                    <Text style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}>
                        {item.femalecount}
                    </Text>
                </View>
                </View>
            </View>
        );
      };
    
      render() {
        return (
          <View style={styles.container}>
            <FlatList
              data={this.state.admissionData}
              ItemSeparatorComponent={this.FlatListItemSeparator}
              renderItem={this.renderItem}
              keyExtractor={() => Math.random().toString(36).substr(2, 9)}
            />
          </View>
        );
      }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#FDFEF1",
      justifyContent: "center"
    },
    submenuItem: {
      flex: 1,
      backgroundColor: "#fff",
      marginBottom: 10,
      paddingBottom: 10,
      paddingTop: 10
    },
    textcontent: {
      fontSize: 14,
      padding: 20
    }
  });