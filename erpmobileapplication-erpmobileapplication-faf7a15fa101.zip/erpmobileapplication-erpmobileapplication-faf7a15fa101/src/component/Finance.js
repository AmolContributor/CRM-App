import React, { Component } from 'react';
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    StatusBar,
    Image,
    Linking,
    CheckBox,
    Switch,
    ListView,
    TabBarIOS,
    ScrollView,
    FlatList,
    Alert,
    Button
  } from "react-native";

export default class FinanceComponent extends Component {
  static navigationOptions = {
        title: "Finance"
      };
    
      constructor() {
        super();
        this.state = {
          invoiceData: []
        };
      }
    
      componentWillMount() {
        this.getFeedbackData(this.props.navigation.state.params);
      }
      
      getFeedbackData(param) {
        return fetch(
          "http://erpwebservice.nikole.in/listdata.php?productid="+param.data.productid
        )
          .then(response => response.json())
          .then(responseJson => {
            this.setState({
              isLoading: true,
              invoiceData: responseJson.invoice
            });
          })
          .catch(error => {
            console.error(error);
          });
      }
    
      FlatListItemSeparator = () => {
        return (
          <View
            style={{
              height: 1,
              width: "100%"
            }}
          />
        );
      };
    
      renderItem = ({ item }) => {
        return (
            <View style={styles.submenuItem}>
                {/* <Text style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}>
                   {item.about}
                </Text> */}
                <View  style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'row' }}>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} > 
                        <Text style={{ marginLeft: 10 ,marginTop: 5, fontSize: 14, textAlign: "left" }}>
                            <Text style={{ fontWeight: "bold"}}> Name: </Text> {item.partyname}
                        </Text>
                    </View>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} >
                        <Text style={{ marginTop: 5, fontSize: 14, textAlign: "left" }}>
                            <Text style={{ fontWeight: "bold"}}> Bill Date: </Text> {item.billdate}
                        </Text>
                    </View>
                </View>
                <View  style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'row' }}>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} >
                        <Text style={{ marginLeft: 10 ,marginTop: 5, fontSize: 14, textAlign: "left" }}>
                            <Text style={{ fontWeight: "bold"}}> Amount: </Text> {item.amount}
                        </Text>
                    </View>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} >
                        <Text style={{ marginTop: 5, fontSize: 14, textAlign: "left" }}>
                            <Text style={{ fontWeight: "bold"}}> Due Date: </Text> {item.mgmtstatusdate}
                        </Text>
                    </View>
                </View>
                <View  style={{ flex: 1, alignSelf: 'stretch', flexDirection: 'row' }}>
                    <View style={{ flex: 1, alignSelf: 'stretch' }} >
                        <Text style={{ marginLeft: 10 ,marginTop: 5, fontSize: 14, textAlign: "left" }}>
                            <Text style={{ fontWeight: "bold"}}> Status: </Text> {item.mgmtstatus ? item.mgmtstatus :'N/A' }
                        </Text>
                    </View>
                </View>
            </View>
        );
      };
    
      render() {
        return (
          <View style={styles.container}>
            <FlatList
              data={this.state.invoiceData}
              ItemSeparatorComponent={this.FlatListItemSeparator}
              renderItem={this.renderItem}
              keyExtractor={() => Math.random().toString(36).substr(2, 9)}
            />
          </View>
        );
      }
}

const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#FDFEF1",
      justifyContent: "center"
    },
    submenuItem: {
      flex: 1,
      backgroundColor: "#fff",
      marginBottom: 10,
      paddingBottom: 10,
      paddingTop: 10
    },
    textcontent: {
      fontSize: 14,
      padding: 20
    }
  });