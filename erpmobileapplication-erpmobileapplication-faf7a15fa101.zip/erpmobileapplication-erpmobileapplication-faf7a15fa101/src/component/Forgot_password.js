import React, { Component } from 'react';
import {
	 StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
} from 'react-native';
//import Login from './app/src/Login';



export default class Forgot_password extends Component {
  static navigationOptions = {
    title: 'Forget Password',
  };

constructor()
  {
    super();
      this.state = {
      email: '',
    };
  }
  render()
  {
  	const { email } = this.state;
     return(
     	<KeyboardAvoidingView behavior="padding" style={styles.container}>
        	<View  style={styles.container}>
        	 <View style={{alignItems:'center'}}>
        		<View style={styles.logincontainer}>
         			<Text  style = {styles.logotitle}>Classroom</Text> 
         			<Text style = {styles.h3bigger}>Find your password</Text>
          			<Text style = {styles.h4}>Enter your phone number or recovery email</Text>
	        		<StatusBar
	      			  barStyle = "light-content"
	        		/>
	        		<View  style = {styles.space}></View>
	        		<TextInput
			        	placeholder = "Phone Number / Email"
			          	placeholderTextColor = '#cccccc'
			          	returnKeyType="next"
			          	keyboardType = "email-address"
			          	autoCorrect = {false}
			          	autoCapitalize = "none"
			          	underlineColorAndroid='#fff'
			          	underlineColorAndroid = "transparent"
			          	onSubmitEditing = {()=> this.passwordInput.focus()}
			          	style = {styles.textInput}
			          	onChangeText={email => this.setState({ email })}
			          	>
			        </TextInput>
					<TouchableOpacity
	          			style ={styles.loginbutton}
	         			//onPress={() => navigate('Forget', "Search Term")}
	         			disabled={!email}
	          		>
	          		<Text style = {styles.loginText} >NEXT</Text>
	        		</TouchableOpacity>
	        	</View>
	        	</View>
      		</View>
        </KeyboardAvoidingView>
       
     );
  }
}
const styles = StyleSheet.create({
logo:{
  flex:1,
  resizeMode:'cover',
  position:'absolute',
  width:'100%',
  height:'100%',
  justifyContent:'center',
},
logotitle:{
	alignSelf:'center',
	marginBottom:30,
	fontWeight: "bold",
},
container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent:'center',
    alignSelf: 'center',
    width:'100%',
//    alignItems:'center'
   
},
profileContainer:{		
	marginLeft:20,
	marginRight:20,
	marginTop:10,
},
header:{
	flex:1,
	alignItems:'center',
	justifyContent:'center',
	//padding:20,
	//backgroundColor:'rgba(0,0,0,0.5)',
},
profilepicWrap:{
	marginTop:5,
	//marginBottom:25,
	width:150,
	height:150,
	borderRadius:100,
	borderColor:'rgba(0,0,0,0.4)',
	borderWidth:16,
	alignSelf:'center',

},
profilepic:{

		flex:1,
		width:null,
		alignSelf:'stretch',
		borderRadius:100,
		borderColor:'#fff',
		borderWidth:4,
},
profilepicchange:{
	marginTop:15,
	marginBottom:35,
	fontSize:16,
	color:'#000',
	fontWeight:'bold',
	alignSelf:'center',
},
logincontainer:{
	//borderRadius: 4,
    //borderWidth: 0.5,
   // borderColor: '#d6d7da',
    //backgroundColor:'#fff',
    marginLeft : 20,
    marginRight:20,
    width:352,
    alignItems:'center',
    height:500,
  //  padding:20,
    justifyContent:'center',
},
h3bigger:{
	fontSize:16,
	marginRight:'85%',
},
h4:{
	fontSize:12,
	marginRight:'65%',
},
loginTextInput:{
	alignSelf: 'stretch',
	padding:2,
	marginBottom: 20,
	backgroundColor: '#fff',
	borderRadius: 4,
    borderWidth: 0.5,
    borderColor: '#d6d7da',
},
loginbutton:{
	
	alignSelf: 'stretch',
	alignItems: 'center',
	backgroundColor:'#3399ff',
	padding:10,
	marginTop:10,
},
loginButton:{
	color:'#fff',
      textAlign:'center',
      paddingLeft : 10,
      paddingRight : 10
},
anchorTag:{
	fontSize:12,
	color:'#000',
	padding:10,
	marginTop:10,
	alignSelf:'center',
},
space:{
	paddingBottom:30,
},
rowView:{
	flexDirection:'row',
	alignSelf:'flex-start',
	justifyContent:'center',
	alignSelf:'center',
},
rowViewText:{
	flex:1,
	flexGrow:1,
	fontSize:12,
	marginTop:8,
},
footer:{
	height:40,
	position:'absolute',
	left:0,
	right:0,
	bottom:0,
	//borderColor:'black',
	//borderRadius: 4,
    //borderWidth: 0.5,
    //justifyContent:'center'
    alignItems:'center',
    alignSelf:'center',

},
DashboardSection:{
	borderRadius: 2,
    borderWidth: 0.3,
    borderColor: '#d6d7da',
    height:'100%',
    marginTop:10,
    backgroundColor: '#fff',
    alignSelf:'center',
    alignItems:'center',
    justifyContent:'center',
    width:'100%',
    
},
Dashbordfooter:{
 height: 56,
          elevation: 8,
          position: 'absolute',
          left: 0,
          bottom: 0,
          right: 0,
   borderTopColor: '#d6d7da',
    borderTopWidth: StyleSheet.hairlineWidth,
},
textInput:{
	//alignSelf: 'stretch',
	padding:2,
	marginTop:5,
	marginBottom: 15,
	//backgroundColor: '#fff',
	//borderRadius: 4,
    //borderWidth: 0.5,
    //borderColor: '#d6d7da',
    borderBottomWidth: 0.5,
    borderBottomColor: '#d6d7da',

}

});
