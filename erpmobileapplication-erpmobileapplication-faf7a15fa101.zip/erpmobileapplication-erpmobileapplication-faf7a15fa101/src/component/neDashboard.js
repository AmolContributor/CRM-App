import React, { Component } from 'react';
import {
    AppRegistry,
    View,
    Text,
    ListView,
    ViewPagerAndroid,
    } from 'react-native';

export default class Dashboard extends React.Component{
    constructor(){
        super();

        this.dataSource = new ListView.DataSource({
            rowHasChanged: (r1, r2) => {
                r1 !== r2
            },
        });

        var data = [];
        for(var i =0;i<10;i++){
            data.push("Row "+i);
        }

        this.state = {
            list: this.dataSource.cloneWithRows(data),
        };
    }

    _renderHeader(){
        return (
            <ViewPagerAndroid
                style={{flex: 1,height:300}}
                initialPage={0}>
                <View style={{alignItems: 'center',justifyContent:'center',backgroundColor:'yellow'}}>
                    <Text style={{color:'red',fontSize:20}}>First page</Text>
                </View>
                <View style={{alignItems: 'center',justifyContent:'center',backgroundColor:'blue'}}>
                    <Text style={{color:'red',fontSize:20}}>Second page</Text>
                </View>
                <View style={{alignItems: 'center',justifyContent:'center',backgroundColor:'black'}}>
                    <Text style={{color:'red',fontSize:20}}>Third page</Text>
                </View>
            </ViewPagerAndroid>
        );
    }

    _renderRow(rowData: string, sectionID: number, rowID: number){
        return(
            <View style={{backgroundColor:'gray',flex:1,height: 40}}>
                <Text>{rowData}</Text>
            </View>
        );
    }

    render(){
        //return this._renderHeader();  //this worked !!
        //Flow code not work!
        return (
            <ListView dataSource={this.state.list}
                      renderHeader={this._renderRow}
                      removeClippedSubviews={false}
                      renderRow={this._renderHeader}/>
        );
    }
}
