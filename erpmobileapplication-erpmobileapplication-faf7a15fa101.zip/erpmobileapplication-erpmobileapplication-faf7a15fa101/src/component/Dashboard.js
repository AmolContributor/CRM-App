import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
  ListView,
  TabBarIOS,
  ScrollView,
  FlatList,
  Alert,
  Button
} from "react-native";
//import Login from './app/src/Login';

import BottomNavigation, { Tab } from "react-native-material-bottom-navigation";
import FontAwesome, { Icons } from "react-native-fontawesome";

export default class Dashboard extends Component {
  static navigationOptions = {
    title: "Dashboard"
  };

  constructor() {
    super();

    this.onPress = this.onPress.bind(this);

    this.state = {
      isLoading: false,
      listItem: []
    };

    // this.state = {

    //   listItem : [
    //     {
    //       key: 'One',
    //       dataSource: [
    //         {
    //           name: 'Admission ',
    //           icon: 'graduationCap',
    //           key:'account'
    //         },
    //         {
    //           name: 'Fee',
    //           icon: 'money',
    //           key:'fee'
    //         },
    //         {
    //           name: 'Finance',
    //           icon: 'money',
    //           key:'finance'
    //         },
    //         {
    //           name: 'Feedback',
    //           icon: 'comment',
    //           key:'feedback'
    //         },
    //       ],
    //     },
    //     {
    //       key: 'Two',
    //       dataSource: [
    //         {
    //           name: 'Admission ',
    //           icon: 'graduationCap',
    //           key:'account'
    //         },
    //         {
    //           name: 'Fee',
    //           icon: 'money',
    //           key:'fee'
    //         },
    //         {
    //           name: 'Finance',
    //           icon: 'money',
    //           key:'finance'
    //         },
    //       ],
    //     },
    //     {
    //       key: 'Three',
    //       dataSource: [
    //         {
    //           name: 'Admission ',
    //           icon: 'graduationCap',
    //           key:'account'
    //         },
    //         {
    //           name: 'Fee',
    //           icon: 'money',
    //           key:'fee'
    //         },
    //         {
    //           name: 'Finance',
    //           icon: 'money',
    //           key:'finance'
    //         },
    //         {
    //           name: 'Feedback',
    //           icon: 'comment',
    //           key:'feedback'
    //         },
    //       ],
    //     },
    //     {
    //       key: 'Four',
    //       dataSource: [
    //         {
    //           name: 'Admission ',
    //           icon: 'graduationCap',
    //           key:'account'
    //         },
    //         {
    //           name: 'Fee',
    //           icon: 'money',
    //           key:'fee'
    //         },
    //         {
    //           name: 'Feedback',
    //           icon: 'comment',
    //           key:'feedback'
    //         },
    //       ],
    //     },
    //   ],
    // }
  }

  componentWillMount() {
    this.getDashboardData();
  }

  getDashboardData() {
    return fetch("http://erff.kij/menu.php")
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: true,
          listItem: responseJson.listItem
        });
      })
      .catch(error => {
        console.error(error);
      });
  }

  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%"
        }}
      />
    );
  };

  GetItem(item) {
    Alert.alert(item);
  }

  onPress = data => {
    // Alert.alert(data.name);
    this.props.navigation.navigate("Institutions", { data });
  };

  renderColumnItems = ({ item }) => {
    return (
      <TouchableOpacity
        style={styles.buttonContainer}
        onPress={() => this.onPress(item)}
      >
        <View style={{ flex: 1 }}>
          <Text style={{ marginTop: 10, fontSize: 30, textAlign: "center" }}>
            <FontAwesome>{Icons[item.icon]}</FontAwesome>
          </Text>
          <Text
            style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}
          >
            {item.name}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  renderItem = ({ item }) => {
    return (
      <View style={styles.submenuItem}>
        <Text style={{ fontSize: 12, textAlign: "center", fontWeight: "bold" }}>
          {item.key}
        </Text>
        <FlatList
          horizontal={true}
          showsHorizontalScrollIndicator={false}
          // style={styles.submenuItem}
          data={item.dataSource}
          renderItem={this.renderColumnItems}
        />
      </View>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <FlatList
          data={this.state.listItem}
          ItemSeparatorComponent={this.FlatListItemSeparator}
          renderItem={this.renderItem}
        />
      </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FDFEF1",
    justifyContent: "center"
  },

  submenuItem: {
    flex: 1,
    // flexDirection     : "row",
    backgroundColor: "#fff",
    // position          : "relative",
    height: 120,
    marginBottom: 10,
    paddingBottom: 10,
    paddingTop: 10
  },

  textcontent: {
    fontSize: 14,
    padding: 20
  },
  buttonContainer: {
    width: 100,
    padding: 10,
    // backgroundColor: '#ccc',
    marginRight: 10
  },
  buttonText: {
    color: "#000",
    textAlign: "center",
    fontWeight: "700"
  }
});
