import React, { Component } from 'react';
import {
  AppRegistry,
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
  Button,
  Form,Alert,
} from 'react-native';
import { SignedOut, SignedIn } from "./router";
import { onSignIn } from "./auth";
import { StackNavigator } from 'react-navigation';


export default class Login extends Component {

  /* DisableButtonFunction =()=>{
     
       this.setState({
         
         // On State True it will Disable the button.
         ButtonStateHolder : false ,
  
        // ButtonTitle : 'Button Disabled'
       
       })
     
    }
  
    SampleButtonFunction=()=>
    {
  
       Alert.alert('Button Clicked') ;
  
    }
 */

  constructor() {
    super();
    this.state = { hidePassword: false }
    this.state = {
      email: '',
      password: '',
    };
  }


  managePasswordVisibility = () => {
    this.setState({ hidePassword: !this.state.hidePassword })
  }

  static navigationOptions = { title: 'Welcome', header: null };

  //Login Function

  UserLoginFunction = () => {

    const { email } = this.state;
    const { password } = this.state;

    if(this.state.email == "erpclass@gmail.com" && this.state.password == "erpclass"){
      this.props.navigation.navigate("SignedIn");
    }
    else{
      Alert.alert("Invalid email/password");
    }

    
    // fetch('http://erpwebservice.nikole.in/Login_section/logincheck.php', {
    //   method: 'POST',
    //   headers: {
    //     'Accept': 'application/json',
    //     'Content-Type': 'application/json',
    //   },
    //   body: JSON.stringify({
    //     email: email,
    //     password: password,
    //   })
    // }).then((response) => response.json())
    //   .then((responseJson) => {
    //     console.log(responseJson);
    //     // Alert.alert(responseJson);
    //   }).catch((error) => {
    //     console.error(error);
    //   });


  }


  render() {
    const { email, password } = this.state;

    return (

      <KeyboardAvoidingView behavior="padding" style={styles.container}>


        <View style={styles.container}>
          <View style={{ alignItems: 'center' }}>

            <View style={styles.logincontainer}>
              <Text style={styles.logotitle}>ERP</Text>
              <Text style={styles.h3bigger}>Sign in</Text>
              <Text style={styles.h4}>with your ERP Account</Text>

              <StatusBar
                barStyle="light-content"
              />
              <View style={styles.space}></View>
              <TextInput
                placeholder="phone number or email"
                placeholderTextColor='#cccccc'
                returnKeyType="next"
                keyboardType="email-address"
                autoCorrect={false}
                autoCapitalize="none"
                underlineColorAndroid="transparent"
                onSubmitEditing={() => this.passwordInput.focus()}
                style={styles.loginTextInput}
                onChangeText={email => this.setState({ email })}
                value={email}
              >
              </TextInput>

              <TextInput
                placeholder="Password"
                placeholderTextColor='#cccccc'
                returnKeyType="go"
                underlineColorAndroid="transparent"
                secureTextEntry={this.state.hidePassword}
                ref={(input) => this.passwordInput = input}
                style={styles.loginTextInput}
                onChangeText={password => this.setState({ password })}
                value={password}
              >
              </TextInput>

              <View style={styles.rowView}>
                <CheckBox
                  onPress={() => {
                    this.setState({ checked: !checked })
                    this._selectedTag()
                  }}
                  onValueChange={this.managePasswordVisibility}
                />
                <Text style={styles.rowViewText}>Hide password</Text>
              </View>
              <TouchableOpacity
                style={styles.loginbutton}
                onPress={() => { 
                  this.UserLoginFunction(); 
                }}

              disabled={!email || !password}
              >
                <Text style={styles.loginButton} >Login</Text>
              </TouchableOpacity>
              <Text
                style={styles.anchorTag}
                onPress={() => this.props.navigation.navigate('Forgot_password')}
              >Forgot your login details?
        </Text>
              <Text style={{textAlign: 'center'}} >
                ___________________  OR  ___________________
        </Text>
              <View style={styles.rowView}>
                <Image
                  style={{ width: 20, height: 20, marginTop: 20 }}
                  source={require('../images/google_logo.jpg')}>
                </Image>
                <Text
                  style={styles.anchorTag}
                onPress={() => Linking.openURL('http://google.com')}
                >Login with gmail
        </Text>
              </View>
            </View>
          </View>
        </View>
      </KeyboardAvoidingView>

    );

  }
}
const styles = StyleSheet.create({
  logo: {
    flex: 1,
    resizeMode: 'cover',
    position: 'absolute',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
  },
  logotitle: {
    alignSelf: 'center',
    marginBottom: 30,
    fontWeight: "bold",
  },
  container: {
    flex: 1,
    backgroundColor: '#fff',
    justifyContent: 'center',
    alignSelf: 'center',
    width: '100%',
    //    alignItems:'center'

  },
  profileContainer: {
    marginLeft: 20,
    marginRight: 20,
    marginTop: 10,
  },
  header: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    //padding:20,
    //backgroundColor:'rgba(0,0,0,0.5)',
  },
  profilepicWrap: {
    marginTop: 5,
    //marginBottom:25,
    width: 150,
    height: 150,
    borderRadius: 100,
    borderColor: 'rgba(0,0,0,0.4)',
    borderWidth: 16,
    alignSelf: 'center',

  },
  profilepic: {

    flex: 1,
    width: null,
    alignSelf: 'stretch',
    borderRadius: 100,
    borderColor: '#fff',
    borderWidth: 4,
  },
  profilepicchange: {
    marginTop: 15,
    marginBottom: 35,
    fontSize: 16,
    color: '#000',
    fontWeight: 'bold',
    alignSelf: 'center',
  },
  logincontainer: {
    //borderRadius: 4,
    //borderWidth: 0.5,
    // borderColor: '#d6d7da',
    //backgroundColor:'#fff',
    marginLeft: 20,
    marginRight: 20,
    width: 352,
    alignItems: 'center',
    // height: 500,
    //  padding:20,
    justifyContent: 'center',
  },
  h3bigger: {
    fontSize: 16,
    marginRight: '85%',
  },
  h4: {
    fontSize: 12,
    marginRight: '65%',
  },
  loginTextInput: {
    alignSelf: 'stretch',
    padding: 2,
    marginBottom: 20,
    backgroundColor: '#fff',
    borderRadius: 4,
    borderWidth: 0.5,
    borderColor: '#d6d7da',
  },
  loginbutton: {

    alignSelf: 'stretch',
    alignItems: 'center',
    backgroundColor: '#3399ff',
    padding: 10,
    marginTop: 10,
  },
  loginButton: {
    color: '#fff',
    textAlign: 'center',
    paddingLeft: 10,
    paddingRight: 10
  },
  anchorTag: {
    fontSize: 12,
    color: '#000',
    padding: 10,
    marginTop: 10,
    alignSelf: 'center',
  },
  space: {
    paddingBottom: 30,
  },
  rowView: {
    flexDirection: 'row',
    alignSelf: 'flex-start',
    justifyContent: 'center',
    alignSelf: 'center',
  },
  rowViewText: {
    flex: 1,
    flexGrow: 1,
    fontSize: 12,
    marginTop: 8,
  },
  footer: {
    // height: 40,
    position: 'absolute',
    left: 0,
    right: 0,
    bottom: 0,
    //borderColor:'black',
    //borderRadius: 4,
    //borderWidth: 0.5,
    //justifyContent:'center'
    alignItems: 'center',
    alignSelf: 'center',

  },
  DashboardSection: {
    borderRadius: 2,
    borderWidth: 0.3,
    borderColor: '#d6d7da',
    // height: '100%',
    marginTop: 10,
    backgroundColor: '#fff',
    alignSelf: 'center',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',

  },
  Dashbordfooter: {
    // height: 56,
    elevation: 8,
    position: 'absolute',
    left: 0,
    bottom: 0,
    right: 0,
    borderTopColor: '#d6d7da',
    borderTopWidth: StyleSheet.hairlineWidth,
  },
  textInput: {
    //alignSelf: 'stretch',
    padding: 2,
    marginTop: 5,
    marginBottom: 15,
    //backgroundColor: '#fff',
    //borderRadius: 4,
    //borderWidth: 0.5,
    //borderColor: '#d6d7da',
    borderBottomWidth: 0.5,
    borderBottomColor: '#d6d7da',

  }

});
