import React, { Component } from "react";
import {
    StyleSheet,
    Text,
    View,
    TextInput,
    TouchableOpacity,
    KeyboardAvoidingView,
    StatusBar,
    Image,
    Linking,
    CheckBox,
    Switch,
    ListView,
    TabBarIOS,
    ScrollView,
    FlatList,
    Alert,
    Button
  } from "react-native";

export default class FeeComponent extends Component {
  static navigationOptions = {
    title: "Fees"
  };

  constructor() {
    super();
    this.state = {
      feeData: []
    };
  }

  componentWillMount() {
    this.getFeeData(this.props.navigation.state.params);
  }
  
  getFeeData(param) {
    return fetch(
      "http://erpwebservice.nikole.in/listdata.php?productid="+param.data.productid
    )
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: true,
          feeData: responseJson.fees
        });
      })
      .catch(error => {
        console.error(error);
      });
  }

  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%"
        }}
      />
    );
  };

  renderItem = ({ item }) => {
    return (
        <View style={styles.submenuItem}>
          <Text
            style={{
              fontSize: 12,
              textAlign: "left",
              fontWeight: "bold",
              padding: 10
            }}
          >
            Total Paid : {item.paidtotal}
          </Text>
        </View>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <FlatList
          data={this.state.feeData}
          ItemSeparatorComponent={this.FlatListItemSeparator}
          renderItem={this.renderItem}
          keyExtractor={() => Math.random().toString(36).substr(2, 9)}
        />
      </View>
    );
  }
}


const styles = StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: "#FDFEF1",
      justifyContent: "center"
    },
    submenuItem: {
      flex: 1,
      backgroundColor: "#fff",
      marginBottom: 10,
      paddingBottom: 10,
      paddingTop: 10
    },
    textcontent: {
      fontSize: 14,
      padding: 20
    }
  });
  