import React, { Component } from "react";
import {
  StyleSheet,
  Text,
  View,
  TextInput,
  TouchableOpacity,
  KeyboardAvoidingView,
  StatusBar,
  Image,
  Linking,
  CheckBox,
  Switch,
  ListView,
  TabBarIOS,
  ScrollView,
  FlatList,
  Alert,
  Button
} from "react-native";
export default class InstitutionList extends Component {
  static navigationOptions = {
    title: "Institutions"
  };

  constructor() {
    super();
    this.onInstitutionSelect = this.onInstitutionSelect.bind(this);
    this.state = {
      insList: [{ key: "top" }]
    };
  }

  componentWillMount() {
    this.getInstitutionsList();
  }

  getInstitutionsList() {
    return fetch(
      "http://erpwebservice.nikole.in/institutelist.php?productid=15961"
    )
      .then(response => response.json())
      .then(responseJson => {
        this.setState({
          isLoading: true,
          insList: responseJson.instituteList
        });
      })
      .catch(error => {
        console.error(error);
      });
  }

  FlatListItemSeparator = () => {
    return (
      <View
        style={{
          height: 1,
          width: "100%"
        }}
      />
    );
  };

  onInstitutionSelect = (data) => {
    // console.log(this.props.navigation.state.params);
    // Alert.alert(data.productid);
    var params = this.props.navigation.state.params;
    this.props.navigation.goBack();
    this.props.navigation.navigate(params.data.key,{ data });
  }

  getDetailList(params){
    return fetch(
        "http://erpwebservice.nikole.in/institutelist.php?productid="+params.productid)
        .then(response => response.json())
        .then(responseJson => {
          this.setState({
            isLoading: true,
            insList: responseJson.fees
          });
        })
        .catch(error => {
          console.error(error);
        });
  }

  renderItem = ({ item }) => {
    return (
      <TouchableOpacity onPress={() => this.onInstitutionSelect(item)}>
        <View style={styles.submenuItem}>
          <Text
            style={{
              fontSize: 12,
              textAlign: "left",
              fontWeight: "bold",
              padding: 10
            }}
          >
            {item.name}
          </Text>
        </View>
      </TouchableOpacity>
    );
  };

  render() {
    return (
      <View style={styles.container}>
        <FlatList
          data={this.state.insList}
          ItemSeparatorComponent={this.FlatListItemSeparator}
          renderItem={this.renderItem}
          keyExtractor={() => Math.random().toString(36).substr(2, 9)}
        />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FDFEF1",
    justifyContent: "center"
  },
  submenuItem: {
    flex: 1,
    backgroundColor: "#fff",
    marginBottom: 10,
    paddingBottom: 10,
    paddingTop: 10
  },
  textcontent: {
    fontSize: 14,
    padding: 20
  }
});
