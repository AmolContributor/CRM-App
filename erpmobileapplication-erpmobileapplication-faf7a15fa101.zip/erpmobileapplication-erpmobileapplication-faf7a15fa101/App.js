import React from "react";
import {
  Alert,
} from 'react-native';
import { createRootNavigator, SignedOut, SignedIn } from "./src/component/router";
import { isSignedIn } from "./src/component/auth";

export default class App extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      signedIn: false,
      checkedSignIn: false
    };
  }
  componentDidlMount() {
    alert('check componentDidlMount');
    isSignedIn()
      .then(res => this.setState({ signedIn: res, checkedSignIn: true }))
      .catch(err => alert("An error occurred"));
  }
  render() {
    const { checkedSignIn, signedIn } = this.state;

    const Layout = createRootNavigator(signedIn);
    return <Layout />;

    // if (signedIn) {
    //   return <SignedOut />;
    // } else {
    //   return <SignedIn />;
    // }
  }
}
